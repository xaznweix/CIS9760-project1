import argparse
import sys 
import os
from sodapy import Socrata
from datetime import date, datetime
import requests
from requests.auth import HTTPBasicAuth
from math import ceil
import time
from elasticsearch import Elasticsearch
from elasticsearch import helpers
import json
# DATASET_ID = "nc67-uf89"
# APP_TOKEN = "1qS9Y7N8k7bAWsGyvAyoX7lo8"
# INDEX_NAME = "parking"
# ES_HOST = "https://search-sta9760f2021wei-pfdud6t6lwf6cby56u2m44lexi.us-east-2.es.amazonaws.com"
# ES_USERNAME = "wei"
# ES_PASSWORD = "Sta9760f2021@"

DATASET_ID = os.environ["DATASET_ID"]
APP_TOKEN = os.environ["APP_TOKEN"]
INDEX_NAME = os.environ["INDEX_NAME"]
ES_HOST = os.environ["ES_HOST"]
ES_USERNAME = os.environ["ES_USERNAME"]
ES_PASSWORD = os.environ["ES_PASSWORD"]

parser = argparse.ArgumentParser(description='Process data from Parking.')
parser.add_argument("--page_size", help="how many rows to get per page", type=int, required = True)
parser.add_argument("--num_pages", help="how many pages to get in total", type=int)

args = parser.parse_args(sys.argv[1:])
print(f" args: {args}")
if __name__ == '__main__':
    try:
        resp = requests.put(
           f"{ES_HOST}/{INDEX_NAME}",
           auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
           json ={
                "settings": {
                    "number_of_shards": 1,
                },
                "mappings": {
                    "properties": {
                        "issue_date": { "type": "date", "format":"MM/dd/yyyy"},
                        "fine_amount": { "type": "float" },
                        "penalty_amount": { "type": "float" },
                        "interest_amount": { "type": "float" },
                        "reduction_amount": { "type": "float" },
                        "payment_amount": { "type": "float" },
                        "amount_due": { "type": "float" },
                        "plate": {"type": "keyword"},
                        "state": {"type":"keyword"},
                        "license_type" : {"type": "keyword"},
                        "violation": {"type": "keyword"},
                        "issuing_agency": {"type": "keyword"},
                        "county": {"type" : "keyword"},
                        "summons_number" :{"type" : "keyword"},
                    }
                }
            }
        )
        resp.raise_for_status()
    except Exception as e:
        print("Index already exists!")
        
    client = Socrata(
        "data.cityofnewyork.us",
        APP_TOKEN,
        
    )
    
    # offset = 0
    # limit = args.page_size
    # number = 0
    # limit = args.page_size
    num_pages = args.num_pages
    if not num_pages:
        resp = client.get(DATASET_ID, select='COUNT(*)')
        num_rows = int(resp[0]['COUNT'])
        num_pages = ceil(num_rows/args.page_size)
    
    
    # es_rows = []
    i = 0
    while i < num_pages:
        rows = client.get(DATASET_ID ,limit = args.page_size , offset = i * args.page_size, order = "summons_number")
        for row in rows:
            try:
                es_row ={}
                es_row["summons_number"] = row["summons_number"]
                if "fine_amount" in row:
                    es_row['fine_amount'] = float(row["fine_amount"])
                es_row['penalty_amount'] = float(row['penalty_amount'])
                es_row['interest_amount'] = float(row['interest_amount'])
                es_row['reduction_amount'] = float(row['reduction_amount'])
                es_row['payment_amount'] = float(row['payment_amount'])
                es_row['amount_due'] = float(row['amount_due'])
                es_row['penalty_amount'] = float(row['penalty_amount'])
                es_row['plate'] = row["plate"]
                es_row['issue_date'] = row['issue_date']
                es_row['state'] = row['state']
                if "violation" in row:
                    es_row['violation'] = row['violation']
                if "county" in row:
                    es_row['county'] = row['county']
            except Exception as e:
                print(f"SKIPPING! because of failure {e}")
                continue
            
            try:
                resp = requests.post(
                    f"{ES_HOST}/{INDEX_NAME}/_doc",
                    auth = HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
                    json = es_row,
                )
                resp.raise_for_status()
            except Exception as e:
                print(f"Failed to upload to elasticsearch! {e}")
        i += 1
